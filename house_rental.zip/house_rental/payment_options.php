<div class="box"><!-- box Starts -->


<h1 class="text-center">Payment Options For You</h1>



<center><!-- center Starts -->
  <a href="paid.php"><img src="images/paypal.png" width="592" height="200" /></a>
</form><!-- form Ends -->

</center><!-- center Ends -->

</div><!-- box Ends -->
