

<?php


 $db=mysql_connect("localhost","root","");
    if (!$db){
        die("Database Connection failed" . mysql_error());
    }
    $db_select = mysql_select_db("ecom_store",$db);
     if (!$db_select){
        die("Database selection failed" . mysql_error());
    }
    ?><center><!-- center Starts -->

<h1>My Orders</h1>

<p class="lead"> Your orders on one place.</p>

<p class="text-muted" >

If you have any questions, please feel free to <a href="../index.php" >BACK TO HOME PAGE</a> our customer service center is working for you 24/7.


</p>


</center>
<!-- center Ends -->

<p>&nbsp;</p>
                    <p>
                      <?php
	// main body 
	 echo "TO CHECK YOUR ORDER USE REFERECE NUMBER";
	 
	 if(isset($_GET['data'])){		 
		 ?>
                    </p>
<table width="345" align="center">
                      <tr>
                        <td><form id="form1" name="form1" method="get" action="">
                          <table width="339" border="1">
                            <tr>
                              <td width="92">ENTER YOUR REFERENCE PAYMENT NO:</td>
                              <td width="17"><label for="search"></label>
                                <input type="hidden" name="adminid" id="adminid" />
                              <td width="124"><input name="search" type="text" required value="" size="20"></td>
                              <td width="628"><input type="submit" name="button" id="button" class="btn btn-primary btn-lg" value="VIEW" /></td>
                            </tr>
                          </table>
                        </form></td>
                      </tr>
                    </table>
                    <p>
                      <?php  }elseif(isset($_GET['button'])){
?>
                    </p>
                    <table width="394" border="1">
                      <tr>
                        <td width="869"><form id="form1" name="form1" method="get" action="">
                          <table width="278" align="center">
                            <tr>
                              <td width="92" height="52">ENTER YOUR REFERENCE PAYMENT NO:</td>
                              <td width="20"><label for="search"></label>
                                <input type="hidden" name="adminid" id="adminid" />
                              <td width="86"><p>
                                <input type="text" name="search" value="" size="20"  required="required"/>
                              </p></td>
                              <td width="556"><input type="submit" name="button" id="button"  class="btn btn-primary btn-lg" value="VIEW" /></td>
                             
                            </tr>
                          </table>
                        </form></td>
                      </tr>
                    </table>
                    <?php
 $search = $_GET['search'];
$sql = mysql_query("SELECT * FROM `payment` WHERE pn LIKE '%$search%'") or die(mysql_error());
?>

                    <style>
.d{
	border:inset;}
                    </style>
<p>CHECK YOUR PAYMENT ORDER</p>
                    <table width="562" border="3" align="left" style=" border:solid;border-color:white;">
                      <tr style="text-transform:uppercase; font-weight:bold; font-size:16px; background:white;">
                        <td width="35"> REFERENCE NO</td>
                        <td width="499">CUSTOMER NAME</td>
                        <td width="142">DATE</td>
                             <td width="142">HOUSE NAME</td>
                                  <td width="142">PRICE</td>
                                       <td width="142">EMAIL</td>
                                            <td width="142">STATUS</td>
                                             <td width="142">PHONE</td>
                      </tr>
                      <?php $n = 0;
  while($row=mysql_fetch_array($sql)){
	  $n = $n +1; 
	  $m = $n%2;
	  if($m == 0){
		  $c = "";
		  }else{
			  $c = "";
			  }
	  ?>
                      <tr style="font-size:16px; font-family:Georgia, 'Times New Roman', Times, serif; background:<?php echo $c;?>; color:;">
                    
                        <td ><?php echo $row['pn']; ?></td>
                        <td ><?php echo $row['accountno']; ?></td>
                        <td ><?php echo $row['date']; ?></td>
                        <td ><?php echo $row['pvc']; ?></td>
                        <td >₦<?php echo $row['fees']; ?></td>
                        <td ><?php echo $row['bank']; ?></td>
                        <td ><?php echo $row['status']; ?></td>
                        <td><?php echo $row['card']; ?></td>
       			      </tr>
                      <?php }?>
                    </table>
                    <?php }elseif(isset($_GET['epdata'])){
echo "epdata";
					 }elseif(isset($_GET['user'])){
	echo "User Login Info:";
$sqlm = mysql_query("SELECT *
FROM `users` WHERE access = 'admin'") or die(mysql_error());
;
	?>
                    <table border="1">
                      <tr>
                        <td>SN</td>
                        <td>Username</td>
                        <td>Password</td>
                        <td>&nbsp;</td>
                      </tr>
                      <?php $nr = 0;
  while($v = mysql_fetch_array($sqlm)){
	  $nr = $nr + 1;
	  ?>
                      <tr>
                        <td><?php echo $nr;?></td>
                        <td><?php echo $v['username'];?></td>
                        <td><?php echo $v[3];?></td>
                        <td><a href="javascript:void(0);" name="Chind window" title="child title" onclick='window.open("users.php?admid=<?php echo $v[0];?>","Rating","width = 800, height = 400,0,status = 0,")'><img src="main_data/b_edit.png" width="16" height="16" alt="ed" /></a></td>
                      </tr>
                      <?php }?>
</table>
                    <?php }elseif(isset($_GET['mpost'])){?>
                    <?php 
	$sql = mysql_query("SELECT * FROM `post` ORDER BY `post`.`date` ASC") or die(mysql_error());

	?>
                    <table id="all">
                      <tr>
                        <td></td>
                        <td bgcolor="#FFFFCC"><strong>Name</strong></td>
                        <td bgcolor="#FFFFCC"><strong>Post</strong></td>
                        <td bgcolor="#FFFFCC"><strong>Time</strong></td>
                        <td bgcolor="#FFFFCC"><strong>Date</strong></td>
                        <td bgcolor="#FFFFCC">&nbsp;</td>
                      </tr>
                      <?php
	$cl = 0;
	 while ($row = mysql_fetch_array($sql)){
		 $cl = $cl +1;
		 $m = ($cl%2);
		$reg = $row[1];
		if($m ==0){
			$color= "#C6C6FF";
			}elseif($m ==1){
				$color= "#CCCCCC";
				}
		$ids = mysql_query("SELECT * FROM data WHERE regno = '$reg'")or die(mysql_error());
		$idd = mysql_fetch_array($ids);
		?>
                      <div >
                        <tr bgcolor="<?php echo $color;?>">
                          <td><a href="javascript:void(0);" name="Chind window" title="child title" onclick='window.open("details.php?appid=<?php echo $idd[0];?>","Rating","width = 1200, height = 700,0,status = 0,")'><img src="upload/<?php echo $row['image'];?>" width="39" height="36" alt="Image"  style="border-radius:10; border:solid; " /> </a><br /></td>
                          <td><?php echo $row[2]." ";?>&nbsp;</td>
                          <td><div><?php echo $row['post'];?>&nbsp;</div></td>
                          <td><span class="back"><?php echo $row[6];?></span></td>
                          <td><em><?php echo $row[5];?></em></td>
                            
                          <td><a href="javascript:void(0);"  name="Chind window" title="child title" onclick='window.open("hides.php?hide=<?php echo $row['status'].'& id='.$row[0]?>","Rating","width = 550, height = 300,0,status = 0,")';>
                            <?php if ($row['status']== 1){
		  echo "Unhide";
		  }else{
			  echo "Hide";
			  }?>
                          </a>&nbsp;</td>
                        </tr>
                        <?php }?>
                      </div>
                    </table>
                    <?php }elseif(isset($_GET['vdepts'])){
								 $dpt_query = mysql_query("SELECT * FROM dept") or die(mysql_error());?>
                    <table border="1">
                      <tr>
                        <td bgcolor="#F8CDE9"><strong>SN</strong></td>
                        <td bgcolor="#F8CDE9"><strong>College</strong></td>
                        <td bgcolor="#F8CDE9"><strong>School</strong></td>
                        <td bgcolor="#F8CDE9"><strong>Department</strong></td>
                        <td bgcolor="#F8CDE9"><strong>Dept-Code</strong></td>
                      </tr>
                      <?php 
  $n = 0;
  while ($row = mysql_fetch_array($dpt_query)){
	  $n = $n + 1;
	  $m = $n % 2;
	  if ($m==0){
		  $color = "#86A4DB";
		  }else{
			$color = "#C0E054";  
			  }
	  ?>
                      <tr bgcolor="<?php echo $color;?>">
                        <td ><?php echo $n;?></td>
                        <td><?php echo $row[1];?></td>
                        <td><?php echo $row[2];?></td>
                        <td><a href="javascript:void(0);" name="Chind window" title="child title" onclick='window.open("album.php?appid=<?php echo $app_id.'& search='.$row[3].'& button=';?>","Rating","width = 1000, height = 600,0,status = 0,")';><?php echo $row[3];?></a></td>
                        <td><?php echo $row[4];?></td>
                      </tr>
                      <?php }?>
                    </table>
                    <br />
                    <a href="javascript:void(0);" name="Chind window" title="child title" onclick='window.open("dept.php?appid=<?php echo $app_id;?>","Rating","width = 550, height = 300,0,status = 0,")';>Add New Department</a>
                    <?php }elseif(isset($_GET['buttons'])){
	  
	  
	  }  
	 ?><!-- table-responsive Ends -->



