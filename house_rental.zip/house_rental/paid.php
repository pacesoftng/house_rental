<?php require_once('Connections/conn.php'); ?>


<?php
if (!function_exists("GetSQLValueString")) {
function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "") 
{
  if (PHP_VERSION < 6) {
    $theValue = get_magic_quotes_gpc() ? stripslashes($theValue) : $theValue;
  }

  $theValue = function_exists("mysql_real_escape_string") ? mysql_real_escape_string($theValue) : mysql_escape_string($theValue);

  switch ($theType) {
    case "text":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;    
    case "long":
    case "int":
      $theValue = ($theValue != "") ? intval($theValue) : "NULL";
      break;
    case "double":
      $theValue = ($theValue != "") ? doubleval($theValue) : "NULL";
      break;
    case "date":
      $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
      break;
    case "defined":
      $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
      break;
  }
  return $theValue;
}
}

mysql_select_db($database_conn, $conn);
$query_Recordset1 = "SELECT * FROM payment";
$Recordset1 = mysql_query($query_Recordset1, $conn) or die(mysql_error());
$row_Recordset1 = mysql_fetch_assoc($Recordset1);
$totalRows_Recordset1 = mysql_num_rows($Recordset1);

 $db=mysql_connect("localhost","root","");
    if (!$db){
        die("Database Connection failed" . mysql_error());
    }
    $db_select = mysql_select_db("ecom_store",$db);
     if (!$db_select){
        die("Database selection failed" . mysql_error());
    }
    ?>
  <!-- MAIN -->
  <main>
    <!-- HERO -->
    <div class="nero">
      <td width="621" valign="top"><p>HOUSE RENT PAYMENT<span class="o"></span>
        <p>&nbsp;</p>
          <table width="100%" border="0" cellspacing="2" cellpadding="2" bgcolor="#0099CC">
            <tr>
              <td bgcolor="#FFFFFF" class="F"><a href="customer/my_account.php?my_orders">Back To Home Page</a></td>
            </tr>
          </table>
          <p class="f">&nbsp;</p>
       <section id="title" class="emerald">
    <div class="container">
      <div class="row"></div>
    </div>
  </section><!--/#title-->     

  <section id="registration" class="container">
    <p>
      <!-- Start Call Action --></p>
    <div class="main">
    <!-- B.1 MAIN CONTENT -->
    <div class="main-content">
      <!-- Pagetitle -->
      <div class="column1-unit">
        <p>
          <?php
		 
		  
if(isset($_POST['button'])){
//upload image	
		  $card=$_POST['card'];
		  $accountno=$_POST['accountno'];
		  $pvc=$_POST['pvc'];
		  $fees=$_POST['fees'];
		  $bank=$_POST['bank'];
		  $date = date('d/m/Y');
		    
		  
		  
		  
		  
		   
		  $query=mysql_query("SELECT *FROM `payment`");
$n = "8234089021";
while ($pt=mysql_fetch_array($query))
{
$n= $n++;
}
$pn = $n.''.rand(1000*100,9999*99); 

$sql = mysql_query("INSERT INTO `payment` (`card`, `accountno`, `date`, `pn`, `pvc`, `fees`, `bank`, `status`)VALUES ('$card', '$accountno', '$date', '$pn', '$pvc', '$fees', '$bank', 'pay')") or die(mysql_error());
echo "<center><script language='javascript'> alert('PAYMENT SUCCEFULLY);</script>";?>
          
          <br />
          HOUSE PAYMENT RECEIPT
</p>
        <p><a href="javascript:window.print()">Print Payment Receipt</a> ||</p>
        <table width="436" height="267" align="center">
          <tr>
          <td width="103" height="43"><strong><span class="style4"> Reference No: </span></strong></td>
          <td width="251"><?php echo $pn;?></td>
        </tr>
        <tr>
          <td height="21"><strong>Customer name:</strong></td>
          <td><?php echo $accountno;?></td>
        </tr>
        <tr>
          <td height="21"><strong>Payment Date :</strong></td>
          <td><?php echo $date;?></td>
        </tr>
          <tr>
          <td height="21"><strong> Price :</strong></td>
          <td>&#8358;<?php echo $fees;?></td>
        </tr>
          <tr>
          <td height="21"><strong>Email:</strong></td>
          <td><?php echo $bank;?></td>
        </tr>
        <tr>
          <td height="21"><strong>Phone No:</strong></td>
          <td><?php echo $card;?></td>
        </tr>
        <tr>
          <td height="40"><strong>Room Order :</strong></td>
          <td><?php echo $pvc;?></td>
        </tr>
        <tr>
          <td height="24"><strong>Payment Status:</strong></td>
          <td><?php echo "Paid";; ?></td>
        </tr>
    </table>
      <?php
exit;
}
		  ?>
      <h1> PAYMENT</h1>
        <form action="" method="post" enctype="multipart/form-data" name="form1" id="form1" onsubmit="MM_validateForm('image','','R','title','R');return document.MM_returnValue">
  <table width="528" height="180" border="1" align="center">
     
     <tr>
      <td width="126">Customer name:</td>
      <td width="618"><input name="accountno" type="text" id="accountno" value="" size="65" required/></td>
      
    </tr>
    <tr>
      <td>Customers Phone:</td>
      <td><input name="card" type="number" id="card" size="65" required/></td>
      
    </tr>
     <tr>
      <td>Date:</td>
      <td><input name="date" type="text" id="date" value="" size="65" /></td>
    </tr>
    
     <tr>
      <td>House name:</td>
      <td><input name="pvc" type="text" id="pvc" value="" size="65" /></td>
    </tr>
    <tr>
      <td>Amount/Price:</td>
      <td><input name="fees" type="number" id="fees" value="" size="65" /></td>
    </tr>
     <tr>
      <td> email:</td>
      <td><input name="bank" type="email" id="bank" value="" size="65" /></td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td><input type="submit" name="button" id="button" value="Complete Payment" />
      &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
    </tr>

  </table>
</form>
        <div class="loginform"></div>
  </div>
    <p>&nbsp;</p>
  </section>
          <p>&nbsp;</p>
          <p>&nbsp;</p>
        
          
        
      <p class="nero__text">
      </p>
    </div>
    <?php
mysql_free_result($Recordset1);
?>
</main><!-- content Ends --><script src="js/jquery.min.js"> </script>

<script src="js/bootstrap.min.js"></script>

</body>
</html>
